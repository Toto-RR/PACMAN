# PACMAN
 Pac-Man Arrangement - DENMA Studios

### CONTROLS
- UP: W key
- LEFT: A key
- RIGHT: D key
- DOWN: S key
- CONTINUE: Spacebar key

Debug functionalities: 
- F1: GodMode
- F2: Colliders
- F3: Win
- F4: Lose
- F6: Next level
- F7: Final level

